@extends('layouts.admin_lay')
@section('content')
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Data Table With Full Features</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">

            <a href="{{url('kt_admin/c_client')}}" class="btn btn-warning pull-right">اضافه عميل  </a>
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>اسم العميل  </th>
                    <th>رقم الفون </th>
                    <th> العنوان </th>
                    <th>صفحه العميل (s)</th>
                    <th>Engine version</th>
                    <th>CSS grade</th>
                </tr>
                </thead>
                <tbody>
                @foreach($client as $row)
                <tr>
                    <td>{{$row->name}}</td>
                    <td>{{$row->phone}}
                    </td>
                    <td>{{$row->address}}
                    </td>
                    <td><a href="{{url('kt_admin/client/'.$row->id)}}" class="btn btn-primary">الصفحه الشخصيه </a> </td>
                    <td> 4</td>
                    <td>X</td>
                </tr>
                @endforeach

                </tbody>
                <tfoot>
                <tr>
                    <th>اسم العميل  </th>
                    <th>رقم الفون </th>
                    <th>صفحه العميل (s)</th>
                    <th> العنوان </th>
                    <th>Engine version</th>
                    <th>CSS grade</th>
                </tr>
                </tfoot>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
@endsection